# TerraPCA - Python Machine Learning & PCA Pipeline

A complete end-to-end Python implementation for **Soil Nutrients with PCA and Feature Engineering** for crop classification and yield prediction.

---

## 📁 Repository Python Files

1. **`soil_pca_pipeline.py`**  
   The complete standalone Python script with all 5 steps:
   - **Step 1: Data Cleaning** (Median imputation, deduplication, IQR outlier detection, domain constraints).
   - **Step 2: Feature Engineering** (Total NPK, Stoichiometric Ratios $N:P, N:K, P:K$, Moisture Index, Fertility Index, Pearson Correlation Heatmap).
   - **Step 3: Principal Component Analysis (PCA)** (`StandardScaler`, `PCA(n_components=3)`, Scree Plot, Factor Loadings Diverging Bar Chart, 2D Biplot).
   - **Step 4: Machine Learning Benchmark** (KNN & Random Forest comparing Full 7D Features vs PCA 3D Components, Confusion Matrix).
   - **Step 5: Live Inference & Yield Simulation** (Takes field soil inputs, projects to PCA coordinates, estimates crop yield in $t/ha$, checks against adjustable target yield line, prescribes Urea/DAP/MOP/Lime fertilizers).

2. **`soil_pca_pipeline.ipynb`**  
   Jupyter Notebook version ready for **Google Colab**, **JupyterLab**, or **VS Code Notebooks**. Contains Markdown explanations, cell-by-cell execution, and embedded visualizations.

3. **`soil_data.csv`**  
   The raw soil dataset containing Nitrogen, Phosphorus, Potassium, Temperature, Humidity, Soil pH, Rainfall, and Crop Labels.

4. **`requirements.txt`**  
   Required Python packages.

---

## 🚀 Quickstart Guide

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```
Or directly:
```bash
pip install pandas numpy scikit-learn matplotlib seaborn
```

### 2. Run the Full Python Pipeline
```bash
python soil_pca_pipeline.py
```

### 3. What it Outputs
- `correlation_heatmap.png`: Pearson correlation matrix of all features.
- `scree_plot.png`: Individual variance bars + cumulative explained variance line with 80% threshold.
- `loadings_barplot.png`: Horizontal diverging bar chart showing positive/negative drivers for PC1, PC2, PC3.
- `pca_biplot.png`: 2D scatter of crop varieties with directional nutrient loading vectors.
- `confusion_matrix.png`: Multi-class confusion matrix of the PCA-reduced model.
- `yield_target_comparison.png`: Crop yield forecast with the adjustable target benchmark line.
- `soil_engineered_pca_processed.csv`: Cleaned dataset with all engineered features and PC coordinates.
